﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.Windows.Forms;

namespace ExecuteCatalogPackageTaskUI
{
    public class ExecuteCatalogPackageTaskUI : IDtsTaskUI
    {
        private TaskHost taskHostValue;
        
        public void New(System.Windows.Forms.IWin32Window form) 
        {

        }
        public ContainerControl GetView()
        {
            return new ExecuteCatalogPackageTaskUIForm(taskHostValue);
        }

        public void Initialize(Microsoft.SqlServer.Dts.Runtime.TaskHost taskHost
                     , System.IServiceProvider serviceProvider)
        {
            taskHostValue = taskHost;
        }

        public void Delete(System.Windows.Forms.IWin32Window form) 
        {

        }
    }
}


