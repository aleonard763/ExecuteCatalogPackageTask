﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.DataTransformationServices.Controls;
using Microsoft.SqlServer.Dts.Runtime;
using ExecuteCatalogPackageTask;
using Microsoft.SqlServer.Dts.Runtime.Design;
using System.ComponentModel;
using System.Collections;
using System.Runtime.CompilerServices;
using Microsoft.SqlServer.Management.IntegrationServices;

namespace ExecuteCatalogPackageTaskComplexUI
{
    public partial class SettingsView : System.Windows.Forms.UserControl, IDTSTaskUIView
    {
        private SettingsNode settingsNode = null;
        private System.Windows.Forms.PropertyGrid settingsPropertyGrid;
        private ExecuteCatalogPackageTask.ExecuteCatalogPackageTask theTask = null;
        private System.ComponentModel.Container components = null;

        private const string NEW_CONNECTION = "<New Connection...>";
        protected IDtsConnectionService ConnectionService { get; set; }

        public SettingsView()
        {
            InitializeComponent();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.settingsPropertyGrid = new System.Windows.Forms.PropertyGrid();
            this.SuspendLayout();
            // settingsPropertyGrid
            this.settingsPropertyGrid.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top
                        | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.settingsPropertyGrid.Location = new System.Drawing.Point(3, 0);
            this.settingsPropertyGrid.Name = "settingsPropertyGrid";
            this.settingsPropertyGrid.PropertySort = System.Windows.Forms.PropertySort.Categorized;
            this.settingsPropertyGrid.Size = new System.Drawing.Size(387, 400);
            this.settingsPropertyGrid.TabIndex = 0;
            this.settingsPropertyGrid.ToolbarVisible = false;
            // SettingsView
            this.Controls.Add(this.settingsPropertyGrid);
            this.Name = "SettingsView";
            this.Size = new System.Drawing.Size(390, 400);
            this.ResumeLayout(false);
            this.settingsPropertyGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propertyGridSettings_PropertyValueChanged);
        }

        public virtual void OnInitialize(IDTSTaskUIHost treeHost
                                       , System.Windows.Forms.TreeNode viewNode
                                       , object taskHost
                                       , object connections)
        {
            if (taskHost == null)
            {
                throw new ArgumentNullException("Attempting to initialize the ExecuteCatalogPackageTask UI with a null TaskHost");
            }

            if (!(((TaskHost)taskHost).InnerObject is ExecuteCatalogPackageTask.ExecuteCatalogPackageTask))
            {
                throw new ArgumentException("Attempting to initialize the ExecuteCatalogPackageTask UI with a task that is not a ExecuteCatalogPackageTask.");
            }

            theTask = ((TaskHost)taskHost).InnerObject as ExecuteCatalogPackageTask.ExecuteCatalogPackageTask;

            this.settingsNode = new SettingsNode(taskHost as TaskHost, connections);

            settingsPropertyGrid.SelectedObject = this.settingsNode;

            ConnectionService = (IDtsConnectionService)connections;

            updateCollections();
        }

        public void OnValidate(ref bool bViewIsValid, ref string reason)
        {
            // throw new NotImplementedException();
        }

        public virtual void OnCommit(object taskHost)
        {
            theTask.ConnectionManagerName = settingsNode.SourceConnection;
            theTask.ServerName = returnSelectedConnectionManagerDataSourceValue(settingsNode.SourceConnection);
            theTask.PackageFolder = settingsNode.Folder;
            theTask.PackageProject = settingsNode.Project;
            theTask.PackageName = settingsNode.Package;
        }

        public void OnSelection()
        {
            // throw new NotImplementedException();
        }

        public void OnLoseSelection(ref bool bCanLeaveView, ref string reason)
        {
            // throw new NotImplementedException();
        }

        private void propertyGridSettings_PropertyValueChanged(object s
                                                             , System.Windows.Forms.PropertyValueChangedEventArgs e)
        {
            if (e.ChangedItem.PropertyDescriptor.Name.CompareTo("SourceConnection") == 0)
            {
                // if a new connection
                if (e.ChangedItem.Value.Equals(NEW_CONNECTION))
                {
                    ArrayList newConnection = new ArrayList();

                    if (!((settingsNode.SourceConnection == null) || (settingsNode.SourceConnection == "")))
                    {
                        settingsNode.SourceConnection = null;
                    }

                    newConnection = ConnectionService.CreateConnection("ADO.Net");

                    if ((newConnection != null) && (newConnection.Count > 0))
                    {
                        ConnectionManager cMgr = (ConnectionManager)newConnection[0];
                        settingsNode.SourceConnection = cMgr.Name;
                        theTask.ServerName = returnSelectedConnectionManagerDataSourceValue(settingsNode.SourceConnection);
                        theTask.ConnectionManagerName = settingsNode.SourceConnection;
                        theTask.ConnectionManagerId = theTask.GetConnectionID(theTask.Connections, theTask.ConnectionManagerName);
                        settingsNode.Connections = ConnectionService.GetConnectionsOfType("ADO.Net");
                    }
                    else
                    {
                        if (e.OldValue == null)
                        {
                            settingsNode.SourceConnection = null;
                        }
                        else
                        {
                            settingsNode.SourceConnection = (string)e.OldValue;
                        }
                    }
                }
                else // if not a new connection
                {
                    theTask.ServerName = returnSelectedConnectionManagerDataSourceValue(settingsNode.SourceConnection);
                    theTask.ConnectionManagerName = settingsNode.SourceConnection;
                    theTask.ConnectionManagerId = theTask.GetConnectionID(theTask.Connections, theTask.ConnectionManagerName);
                    settingsNode.Connections = ConnectionService.GetConnectionsOfType("ADO.Net");
                }
                updateCollections();
                resetCollections("Connections");
            }

            if (e.ChangedItem.PropertyDescriptor.Name.CompareTo("Folder") == 0)
            {
                updateCollections();
                resetCollections("Folders");
            }

            if (e.ChangedItem.PropertyDescriptor.Name.CompareTo("Project") == 0)
            {
                updateCollections();
                resetCollections("Projects");
            }

            if (e.ChangedItem.PropertyDescriptor.Name.CompareTo("Package") == 0)
            {
                updateCollections();
            }

            if ((e.ChangedItem.PropertyDescriptor.Name.CompareTo("MaximumRetries") == 0)
             || (e.ChangedItem.PropertyDescriptor.Name.CompareTo("RetryIntervalSeconds") == 0))
            {
                int retriesTimesIntervalSeconds = settingsNode.MaximumRetries
                     * settingsNode.RetryIntervalSeconds;
                int operationTimeoutSeconds = settingsNode.OperationTimeoutMinutes * 60;
                settingsNode.OperationTimeoutMinutes = (int)((retriesTimesIntervalSeconds / 60) + 1);
                this.settingsPropertyGrid.Refresh();
            }

        }

        private void resetCollections(string collectionName)
        {
            Cursor = Cursors.WaitCursor;

            switch (collectionName)
            {
                default:
                    break;
                case "Connections":
                    settingsNode.Folder = "";
                    settingsNode.Project = "";
                    settingsNode.Package = "";
                    break;
                case "Folders":
                    settingsNode.Project = "";
                    settingsNode.Package = "";
                    break;
                case "Projects":
                    settingsNode.Package = "";
                    break;
            }

            Cursor = Cursors.Default;
        }

        private void updateCollections()
        {
            Cursor = Cursors.WaitCursor;

            updateFolders();
            updateProjects();
            updatePackages();

            Cursor = Cursors.Default;
        }

        private void updateFolders()
        {
            if (settingsNode.SourceConnection != "")
            {
                settingsNode.Folders = settingsNode.GetFoldersFromCatalog();
                this.settingsPropertyGrid.Refresh();
            }
        }

        private void updateProjects()
        {
            if ((settingsNode.SourceConnection != "")
             && (settingsNode.Folder != ""))

            {
                settingsNode.Projects = settingsNode.GetProjectsFromCatalog();
                this.settingsPropertyGrid.Refresh();
            }
        }

        private void updatePackages()
        {
            if ((settingsNode.SourceConnection != "")
             && (settingsNode.Folder != "")
             && (settingsNode.Project != ""))
            {
                settingsNode.Packages = settingsNode.GetPackagesFromCatalog();
                this.settingsPropertyGrid.Refresh();
            }
        }

        private string returnSelectedConnectionManagerDataSourceValue(string connectionManagerName)
        {
            string ret = String.Empty;

            ArrayList listConnections = (ArrayList)settingsNode.Connections;
            string connectionString = String.Empty;

            // match the selected ADO.Net connection manager
            foreach (ConnectionManager cm in listConnections)
            {
                if (cm.Name == connectionManagerName)
                {
                    connectionString = cm.ConnectionString;
                }
            }

            // parse if a match is found
            if (connectionString != String.Empty)
            {
                string dataSourceStartText = "Data Source=";
                string dataSourceEndText = ";";
                int dataSourceTagStart = connectionString.IndexOf(dataSourceStartText) + dataSourceStartText.Length;
                int dataSourceTagEnd = 0;
                int dataSourceTagLength = 0;
                if (dataSourceTagStart > 0)
                {
                    dataSourceTagEnd = connectionString.IndexOf(dataSourceEndText, dataSourceTagStart);
                    if (dataSourceTagEnd > dataSourceTagStart)
                    {
                        dataSourceTagLength = dataSourceTagEnd - dataSourceTagStart;
                        ret = connectionString.Substring(dataSourceTagStart, dataSourceTagLength);
                    }
                }
            }

            return ret;
        }
    }

    internal class SettingsNode
    {
        internal ExecuteCatalogPackageTask.ExecuteCatalogPackageTask _task = null;
        private TaskHost _taskHost = null;
        private object _connections = null;

        private object _folders = null;
        private object _projects = null;
        private object _packages = null;

        private const string NEW_CONNECTION = "<New Connection...>";

        public SettingsNode(TaskHost taskHost
                          , object connections)
        {
            _taskHost = taskHost;
            _task = taskHost.InnerObject as ExecuteCatalogPackageTask.ExecuteCatalogPackageTask;
            _connections = ((IDtsConnectionService)connections).GetConnectionsOfType("ADO.Net");
        }

        //[
        //    Category("SSIS Catalog Package Properties"),
        //    Description("Enter SSIS Catalog Package folder name.")
        //]
        //public string FolderName {
        //    get { return _task.PackageFolder; }
        //    set {
        //        if ((value == null) || (value.Trim().Length == 0))
        //        {
        //            throw new ApplicationException("Folder name cannot be empty");
        //        }

        //        _task.PackageFolder = value;
        //    }
        //}

        [
            Category("SSIS Catalog Package Properties"),
            Description("Select SSIS Catalog Package folder name."),
            TypeConverter(typeof(Folders))
        ]
        public string Folder {
            get { return _task.PackageFolder; }
            set {
                if (value == null)
                {
                    throw new ApplicationException("Folder name cannot be empty");
                }

                _task.PackageFolder = value;
            }
        }

        [
            Category("SSIS Catalog Package Path Collections"),
            Description("Enter SSIS Catalog Package folders collection."),
            Browsable(false)
        ]
        public object Folders {
            get { return _folders; }
            set { _folders = value; }
        }

        internal ArrayList GetFoldersFromCatalog()
        {
            ArrayList foldersList = new ArrayList();

            if ((_task.ServerName != null) && (_task.ServerName != ""))
            {
                Catalog catalog = _task.returnCatalog(_task.ServerName);

                if (catalog != null)
                {
                    foreach (CatalogFolder cf in catalog.Folders)
                    {
                        foldersList.Add(cf.Name);
                    }
                }
            }
            return foldersList;
        }

        //[
        //  Category("SSIS Catalog Package Properties"),
        //  Description("Enter SSIS Catalog Package project name.")
        //]
        //public string ProjectName {
        //    get { return _task.PackageProject; }
        //    set {
        //        if ((value == null) || (value.Trim().Length == 0))
        //        {
        //            throw new ApplicationException("Project name cannot be empty");
        //        }

        //        _task.PackageProject = value;
        //    }
        //}

        [
            Category("SSIS Catalog Package Path Collections"),
            Description("Enter SSIS Catalog Package projects collection."),
            Browsable(false)
        ]
        public object Projects {
            get { return _projects; }
            set { _projects = value; }
        }

        [
            Category("SSIS Catalog Package Properties"),
            Description("Select SSIS Catalog Package project name."),
            TypeConverter(typeof(Projects))
        ]
        public string Project {
            get { return _task.PackageProject; }
            set {
                if (value == null)
                {
                    throw new ApplicationException("Project name cannot be empty");
                }

                _task.PackageProject = value;
            }
        }

        internal ArrayList GetProjectsFromCatalog()
        {
            ArrayList projectsList = new ArrayList();

            if (((_task.ServerName != null) && (_task.ServerName != ""))
             && ((_task.PackageFolder != null) && (_task.PackageFolder != "")))
            {
                CatalogFolder catalogFolder = _task.returnCatalogFolder(_task.ServerName
                                                                 , _task.PackageFolder);

                if (catalogFolder != null)
                {
                    foreach (ProjectInfo pr in catalogFolder.Projects)
                    {
                        projectsList.Add(pr.Name);
                    }
                }
            }
            return projectsList;
        }

        //[
        //  Category("SSIS Catalog Package Properties"),
        //  Description("Enter SSIS Catalog Package name.")
        //]
        //public string PackageName {
        //    get { return _task.PackageName; }
        //    set {
        //        if ((value == null) || (value.Trim().Length == 0))
        //        {
        //            throw new ApplicationException("Package name cannot be empty");
        //        }

        //        _task.PackageName = value;
        //    }
        //}

        [
            Category("SSIS Catalog Package Properties"),
            Description("Select SSIS Catalog Package name."),
            TypeConverter(typeof(Packages))
        ]
        public string Package {
            get { return _task.PackageName; }
            set {
                if (value == null)
                {
                    throw new ApplicationException("Package name cannot be empty");
                }

                _task.PackageName = value;
            }
        }

        [
            Category("SSIS Catalog Package Path Collections"),
            Description("Enter SSIS Catalog Packages collection."),
            Browsable(false)
        ]
        public object Packages {
            get { return _packages; }
            set { _packages = value; }
        }

        internal ArrayList GetPackagesFromCatalog()
        {
            ArrayList packagesList = new ArrayList();

            if (((_task.ServerName != null) && (_task.ServerName != ""))
             && ((_task.PackageFolder != null) && (_task.PackageFolder != ""))
             && ((_task.PackageProject != null) && (_task.PackageProject != "")))
            {
                ProjectInfo catalogProject = _task.returnCatalogProject(_task.ServerName
                                                                 , _task.PackageFolder
                                                                 , _task.PackageProject);

                if (catalogProject != null)
                {
                    foreach (Microsoft.SqlServer.Management.IntegrationServices.PackageInfo
                               pkg in catalogProject.Packages)
                    {
                        packagesList.Add(pkg.Name);
                    }
                }
            }
            return packagesList;
        }

        [
            Browsable(false)
        ]
        internal object Connections {
            get { return _connections; }
            set { _connections = value; }
        }

        [
           Category("Connections"),
           Description("The SSIS Catalog connection"),
           TypeConverter(typeof(ADONetConnections))
        ]
        public string SourceConnection {
            get { return _task.ConnectionManagerName; }
            set { _task.ConnectionManagerName = value; }
        }

        [
            Category("SSIS Package Execution Properties"),
            Description("Enter SSIS Catalog Package Use32bit execution property value.")
        ]
        public bool Use32bit {
            get { return _task.Use32bit; }
            set { _task.Use32bit = value; }
        }

        [
            Category("SSIS Package Synchronized Properties"),
            Description("Enter SSIS Catalog Package SYNCHRONIZED execution parameter value.")
        ]
        public bool Synchronized {
            get { return _task.Synchronized; }
            set { _task.Synchronized = value; }
        }

        [
  Category("SSIS Package Synchronized Properties"),
  Description("Enter SSIS Catalog Package Maximum Retries " +
              "for the timer \"tick\" when SYNCHRONIZED is true.")
]
        public int MaximumRetries {
            get { return _task.MaximumRetries; }
            set { _task.MaximumRetries = value; }
        }

        [
          Category("SSIS Package Synchronized Properties"),
          Description("Enter SSIS Catalog Package Retry Interval Seconds " +
                 "to wait between timer \"tick\" retries when SYNCHRONIZED is true.")
        ]
        public int RetryIntervalSeconds {
            get { return _task.RetryIntervalSeconds; }
            set { _task.RetryIntervalSeconds = value; }
        }

        [
            Category("SSIS Package Synchronized Properties"),
            Description("The SSIS Catalog Package Operation Timeout Minutes - " +
                        "managed by RetryIntervalSeconds and MaximumRetires when SYNCHRONIZED is true."),
            ReadOnly(true)
        ]
        public int OperationTimeoutMinutes {
            get { return _task.OperationTimeoutMinutes; }
            set { _task.OperationTimeoutMinutes = value; }
        }

        [
            Category("SSIS Package Execution Properties"),
            Description("Enter SSIS Catalog Package LOGGING_LEVEL execution parameter value."),
            TypeConverter(typeof(LoggingLevels))
        ]
        public string LoggingLevel {
            get { return _task.LoggingLevel; }
            set { _task.LoggingLevel = value; }
        }
    }

    internal class ADONetConnections : StringConverter
    {
        private const string NEW_CONNECTION = "<New Connection...>";

        private object GetSpecializedObject(object contextInstance)
        {
            DTSLocalizableTypeDescriptor typeDescr = contextInstance as DTSLocalizableTypeDescriptor;

            if (typeDescr == null)
            {
                return contextInstance;
            }

            return typeDescr.SelectedObject;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            object retrievalObject = GetSpecializedObject(context.Instance) as object;

            return new StandardValuesCollection(getADONetConnections(retrievalObject));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        private ArrayList getADONetConnections(object retrievalObject)
        {
            SettingsNode node = (SettingsNode)retrievalObject;
            ArrayList list = new ArrayList();
            ArrayList listConnections = new ArrayList();

            listConnections = (ArrayList)node.Connections;

            // adds the new connection item
            list.Add(NEW_CONNECTION);

            // adds each ADO.Net connection manager
            foreach (ConnectionManager cm in listConnections)
            {
                list.Add(cm.Name);
            }

            // sorts the connection manager list
            if ((list != null) && (list.Count > 0))
            {
                list.Sort();
            }

            return list;
        }
    }

    internal class Folders : StringConverter
    {
        private object GetSpecializedObject(object contextInstance)
        {
            DTSLocalizableTypeDescriptor typeDescr = contextInstance as DTSLocalizableTypeDescriptor;

            if (typeDescr == null)
            {
                return contextInstance;
            }

            return typeDescr.SelectedObject;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            object retrievalObject = GetSpecializedObject(context.Instance) as object;

            return new StandardValuesCollection(getFolders(retrievalObject));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        private ArrayList getFolders(object retrievalObject)
        {
            SettingsNode node = (SettingsNode)retrievalObject;
            ArrayList list = new ArrayList();
            ArrayList listFolders;

            listFolders = (ArrayList)node.Folders;
            if (listFolders == null)
            {
                listFolders = new ArrayList();
            }

            if (listFolders != null)
            {
                // adds each folder
                foreach (string fld in listFolders)
                {
                    list.Add(fld); // Folder name
                }

                // sorts the folder list
                if ((list != null) && (list.Count > 0))
                {
                    list.Sort();
                }
            }

            return list;
        }
    }

    internal class Projects : StringConverter
    {
        private object GetSpecializedObject(object contextInstance)
        {
            DTSLocalizableTypeDescriptor typeDescr = contextInstance as DTSLocalizableTypeDescriptor;

            if (typeDescr == null)
            {
                return contextInstance;
            }

            return typeDescr.SelectedObject;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            object retrievalObject = GetSpecializedObject(context.Instance) as object;

            return new StandardValuesCollection(getProjects(retrievalObject));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        private ArrayList getProjects(object retrievalObject)
        {
            SettingsNode node = (SettingsNode)retrievalObject;
            ArrayList list = new ArrayList();
            ArrayList listProjects;

            listProjects = (ArrayList)node.Projects;
            if (listProjects == null)
            {
                listProjects = new ArrayList();
            }

            if (listProjects != null)
            {
                // adds each project
                foreach (string fld in listProjects)
                {
                    list.Add(fld); // Project name
                }

                // sorts the project list
                if ((list != null) && (list.Count > 0))
                {
                    list.Sort();
                }
            }

            return list;
        }
    }

    internal class Packages : StringConverter
    {
        private object GetSpecializedObject(object contextInstance)
        {
            DTSLocalizableTypeDescriptor typeDescr = contextInstance as DTSLocalizableTypeDescriptor;

            if (typeDescr == null)
            {
                return contextInstance;
            }

            return typeDescr.SelectedObject;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            object retrievalObject = GetSpecializedObject(context.Instance) as object;

            return new StandardValuesCollection(getPackages(retrievalObject));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        private ArrayList getPackages(object retrievalObject)
        {
            SettingsNode node = (SettingsNode)retrievalObject;
            ArrayList list = new ArrayList();
            ArrayList listPackages;

            listPackages = (ArrayList)node.Packages;
            if (listPackages == null)
            {
                listPackages = new ArrayList();
            }

            if (listPackages != null)
            {
                // adds each package
                foreach (string pkg in listPackages)
                {
                    list.Add(pkg); // Package name
                }

                // sorts the package list
                if ((list != null) && (list.Count > 0))
                {
                    list.Sort();
                }
            }

            return list;
        }
    }

    internal class LoggingLevels : StringConverter
    {
        private object GetSpecializedObject(object contextInstance)
        {
            DTSLocalizableTypeDescriptor typeDescr = contextInstance as DTSLocalizableTypeDescriptor;

            if (typeDescr == null)
            {
                return contextInstance;
            }

            return typeDescr.SelectedObject;
        }

        public override StandardValuesCollection GetStandardValues(ITypeDescriptorContext context)
        {
            object retrievalObject = GetSpecializedObject(context.Instance) as object;

            return new StandardValuesCollection(getLoggingLevels(retrievalObject));
        }

        public override bool GetStandardValuesExclusive(ITypeDescriptorContext context)
        {
            return true;
        }

        public override bool GetStandardValuesSupported(ITypeDescriptorContext context)
        {
            return true;
        }

        private ArrayList getLoggingLevels(object retrievalObject)
        {
            ArrayList logLevelsArray = new ArrayList();

            logLevelsArray.Add("None");
            logLevelsArray.Add("Basic");
            logLevelsArray.Add("Performance");
            logLevelsArray.Add("Verbose");

            return logLevelsArray;
        }
    }
}
