﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.SqlServer.Dts.Runtime;
using Microsoft.SqlServer.Management.IntegrationServices;
using Microsoft.SqlServer.Management.Smo;

namespace ExecuteCatalogPackageTask
{
    [DtsTask(
        TaskType = "DTS140"
      , DisplayName = "Execute Catalog Package Task"
      , IconResource = "ExecuteCatalogPackageTask.ALCStrike.ico"
      , Description = "A task to execute packages stored in the SSIS Catalog."
      , UITypeName = "ExecuteCatalogPackageTaskComplexUI.ExecuteCatalogPackageTaskComplexUI, ExecuteCatalogPackageTaskComplexUI, Version=1.0.0.0, Culture=Neutral, PublicKeyToken=a68173515d1ee3e3"
      , TaskContact = "ExecuteCatalogPackageTask; Building Custom Tasks for SQL Server Integration Services, 2019 Edition; © 2020 Andy Leonard; https://dilmsuite.com/ExecuteCatalogPackageTaskBookCode")]
    public class ExecuteCatalogPackageTask : Microsoft.SqlServer.Dts.Runtime.Task
    {
        // Public key: e86e33313a45419e
        //             e4f20b7aa35f375d -- key for simple UI
        //             a68173515d1ee3e3 -- key for complex UI

        public string TaskName { get; set; } = "Execute Catalog Package Task";
        public string TaskDescription { get; set; } = "Execute Catalog Package Task";
        public Connections Connections;
        public string ConnectionManagerName { get; set; } = String.Empty;
        public string ConnectionManagerId { get; set; } = String.Empty;
        public int ConnectionManagerIndex { get; set; } = -1;
        public bool Synchronized { get; set; } = false;
        public int MaximumRetries { get; set; } = 29;
        public int RetryIntervalSeconds { get; set; } = 10;
        public int OperationTimeoutMinutes { get; set; } = 5;
        public bool Use32bit { get; set; } = false;
        public string LoggingLevel { get; set; } = "Basic";
        public string ServerName { get; set; } = String.Empty;
        private Server catalogServer { get; set; } = null;
        private IntegrationServices integrationServices { get; set; } = null;
        public string PackageCatalogName { get; set; } = "SSISDB";
        private Catalog catalog { get; set; } = null;
        public string PackageFolder { get; set; } = String.Empty;
        private CatalogFolder catalogFolder { get; set; } = null;
        public string PackageProject { get; set; } = String.Empty;
        private ProjectInfo catalogProject { get; set; } = null;
        public string PackageName { get; set; } = String.Empty;
        private Microsoft.SqlServer.Management.IntegrationServices.PackageInfo catalogPackage { get; set; } = null;
        private IDTSComponentEvents componentEvents { get; set; } = null;

        public override void InitializeTask(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSInfoEvents events,
            IDTSLogging log,
            EventInfos eventInfos,
            LogEntryInfos logEntryInfos,
            ObjectReferenceTracker refTracker)
        {
            // init Connections
            Connections = connections;
        }

        public override DTSExecResult Validate(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSComponentEvents componentEvents,
            IDTSLogging log)
        {
            // initialize componentEvents
            this.componentEvents = componentEvents;

            // init validateResult
            DTSExecResult validateResult = DTSExecResult.Success;

            // test for SourceConnection (ConnectionManagerName and ServerName) existence
            try
            {
                if ((ConnectionManagerName == "") || (ServerName == ""))
                {
                    raiseEvent("Error"
                       , -1001
                       , TaskName
                       , "Source Connection property is not configured.");
                    validateResult = DTSExecResult.Failure;

                    // attempt to connect
                    bool connectionAttempt = attemptConnection(connections
                        , ConnectionManagerIndex);
                    if (!connectionAttempt)
                    {
                        raiseEvent("Error"
                            , -1002
                            , TaskName
                            , "SQL Server Instance Connection attempt failed.");

                        validateResult = DTSExecResult.Failure;
                    }
                }
            }
            catch (Exception ex)
            {
                if (componentEvents != null)
                {
                    // fire a generic error containing exception details
                    raiseEvent("Error"
                       , -1001
                       , TaskName
                       , ex.Message);
                }

                // manage validateResult state
                validateResult = DTSExecResult.Failure;
            }

            // test for Folder property existence
            if (validateResult != DTSExecResult.Failure)
            {
                try
                {
                    if (PackageFolder == "")
                    {
                        raiseEvent("Error"
                          , -1003
                          , TaskName
                          , "Folder property is not configured.");
                        validateResult = DTSExecResult.Failure;
                    }

                    // attempt to retrieve folder
                    CatalogFolder validateFolder = returnCatalogFolder(
                         ServerName
                       , PackageFolder);

                    if (validateFolder == null)
                    {
                        raiseEvent("Error"
                           , -1003
                           , TaskName
                           , "Failed to retrieve Catalog Folder.");
                        validateResult = DTSExecResult.Failure;
                    }

                }
                catch (Exception exf)
                {
                    if (componentEvents != null)
                    {
                        // fire a generic error containing exception details
                        raiseEvent("Error"
                           , -1003
                           , TaskName
                           , exf.Message);
                    }

                    // manage validateResult state
                    validateResult = DTSExecResult.Failure;
                }
            }

            // test for Project property existence
            if (validateResult != DTSExecResult.Failure)
            {
                try
                {
                    if (PackageProject == "")
                    {
                        raiseEvent("Error"
                           , -1004
                           , TaskName
                           , "Project property is not configured.");
                        validateResult = DTSExecResult.Failure;
                    }

                    // attempt to retrieve project
                    ProjectInfo validateProject = returnCatalogProject(
                       ServerName
                       , PackageFolder
                       , PackageProject);

                    if (validateProject == null)
                    {
                        raiseEvent("Error"
                           , -1004
                           , TaskName
                           , "Failed to retrieve Catalog Project.");
                        validateResult = DTSExecResult.Failure;
                    }
                }
                catch (Exception expr)
                {
                    if (componentEvents != null)
                    {
                        // fire a generic error containing exception details
                        raiseEvent("Error"
                           , -1004
                           , TaskName
                           , expr.Message);
                    }

                    // manage validateResult state
                    validateResult = DTSExecResult.Failure;
                }
            }

            // test for Package property existence
            if (validateResult != DTSExecResult.Failure)
            {
                try
                {
                    if (PackageName == "")
                    {
                        raiseEvent("Error"
                           , -1005
                           , TaskName
                           , "Package property is not configured.");
                        validateResult = DTSExecResult.Failure;
                    }

                    // attempt to retrieve package
                    Microsoft.SqlServer.Management.IntegrationServices.PackageInfo
                       validatePackage = returnCatalogPackage(
                            ServerName
                          , PackageFolder
                          , PackageProject
                          , PackageName);

                    if (validatePackage == null)
                    {
                        raiseEvent("Error"
                           , -1005
                           , TaskName
                           , "Failed to retrieve Catalog Package.");
                        validateResult = DTSExecResult.Failure;
                    }
                }
                catch (Exception expkg)
                {
                    if (componentEvents != null)
                    {
                        // fire a generic error containing exception details
                        raiseEvent("Error"
                           , -1005
                           , TaskName
                           , expkg.Message);
                    }

                    // manage validateResult state
                    validateResult = DTSExecResult.Failure;
                }
            }

            return validateResult;
        }


        public override DTSExecResult Execute(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSComponentEvents componentEvents,
            IDTSLogging log,
            object transaction)
        {
            return ExecuteCatalogPackage(); ;
        }

        private DTSExecResult ExecuteCatalogPackage()
        {
            DTSExecResult executionResult;

            ConnectionManagerIndex = returnConnectionManagerIndex(Connections
                                                       , ConnectionManagerName);
            
            catalogProject = returnCatalogProject(ServerName
                                                , PackageFolder
                                                , PackageProject);
            catalogPackage = returnCatalogPackage(ServerName
                                                , PackageFolder
                                                , PackageProject
                                                , PackageName);
            Collection<Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet>
            executionValueParameterSet = returnExecutionValueParameterSet();

            string packagePath = "\\SSISDB\\" + PackageFolder + "\\"
                               + PackageProject + "\\"
                               + PackageName;
            string msg = "Starting " + packagePath + " on " + ServerName + ".";
            raiseEvent("Information", 1001, TaskName, msg);

            Stopwatch sw = new Stopwatch();
            sw.Start();

            long executionId = catalogPackage.Execute(Use32bit
                                                    , null
                                                    , executionValueParameterSet);

            SqlConnection connection = returnConnection();

            Operation.ServerOperationStatus operationStatus;

            if (Synchronized)
            {
                operationStatus = executeSynchronous(executionId
                                                   , connection);

                if (operationStatus == Operation.ServerOperationStatus.Canceled)
                {
                    stopExecution(executionId
                                , connection);
                }
                sw.Stop();
            }
            else
            {
                sw.Stop();
                operationStatus = returnOperationStatus(connection
                                                      , executionId);
            }

            executionResult = evaluateStatus(operationStatus
                                           , packagePath
                                           , sw.Elapsed.ToString());

            return executionResult;
        }

        private Operation.ServerOperationStatus executeSynchronous(long executionId
                              , SqlConnection connection)
        {
            Operation.ServerOperationStatus ret = Operation.ServerOperationStatus.UnexpectTerminated;
            ManualResetEvent manualResetState = new ManualResetEvent(false);

            CheckWaitState statusChecker = new CheckWaitState(executionId
                                                            , MaximumRetries
                                                            , connection
                                                            , PackageCatalogName
                                                            , this);
            TimeSpan dueTime = new TimeSpan(0, 0, 0);
            TimeSpan period = new TimeSpan(0, 0, RetryIntervalSeconds);

            object timerState = new TimerCheckerState(manualResetState);
            TimerCallback timerCallback = statusChecker.CheckStatus;
            Timer timer = new Timer(timerCallback, timerState, dueTime, period);

            WaitHandle[] manualResetStateWaitHandleCollection = new WaitHandle[]
                        { manualResetState };
            int timeoutMillseconds = (int)new TimeSpan(0, OperationTimeoutMinutes
                                                        , 0).TotalMilliseconds;
            bool exitContext = false;

            // wait here, please
            WaitHandle.WaitAny(manualResetStateWaitHandleCollection
                             , timeoutMillseconds
                             , exitContext);

            ret = statusChecker.OperationStatus;

            manualResetState.Dispose();
            timer.Dispose();

            return ret;
        }

        private DTSExecResult evaluateStatus(Operation.ServerOperationStatus os
                                   , string packagePath
                                   , string elapsed)
        {
            DTSExecResult ret = DTSExecResult.Success;
            string msg = String.Empty;
            string swMsg = String.Empty;

            if (Synchronized)
            {
                swMsg = " Package Execution Time: " + elapsed;
            }

            switch (os)
            {
                default:
                    break;
                case Operation.ServerOperationStatus.Success:
                    msg = packagePath + " on " + ServerName + (Synchronized ?
                          (" succeeded." + swMsg.Substring(0, (swMsg.Length - 4))) :
                          (" started. Check SSIS Catalog Reports for package execution results."));
                    raiseEvent((Synchronized ? "Information" : "Warning")
                      , 1099, TaskName, msg);
                    ret = DTSExecResult.Success;
                    break;
                case Operation.ServerOperationStatus.Created:
                case Operation.ServerOperationStatus.Pending:
                case Operation.ServerOperationStatus.Running:
                    msg = packagePath + " on " + ServerName + (Synchronized ?
                          (" " + os.ToString().ToLower() + "." + swMsg.Substring(0, (swMsg.Length - 4))) :
                          (" started. Check SSIS Catalog Reports for package execution results."));
                    raiseEvent((Synchronized ? "Information" : "Warning")
                      , 1099, TaskName, msg);
                    ret = DTSExecResult.Success;
                    break;
                case Operation.ServerOperationStatus.Failed:
                    msg = packagePath + " on " + ServerName + (Synchronized ?
                          (" failed." + swMsg.Substring(0, (swMsg.Length - 4))) :
                          (" started. Check SSIS Catalog Reports for package execution results."));
                    raiseEvent("Error", -1099, TaskName, msg);
                    ret = DTSExecResult.Failure;
                    break;
                case Operation.ServerOperationStatus.UnexpectTerminated:
                    msg = packagePath + " on " + ServerName + (Synchronized ?
                          (" terminated unexpectedly." + swMsg.Substring(0, (swMsg.Length - 4))) :
                          (" started. Check SSIS Catalog Reports for package execution results."));
                    raiseEvent("Error", -1099, TaskName, msg);
                    ret = DTSExecResult.Failure;
                    break;
                case Operation.ServerOperationStatus.Canceled:
                    msg = packagePath + " on " + ServerName + (Synchronized ?
                          (" was canceled." + swMsg.Substring(0, (swMsg.Length - 4))) :
                          (" started. Check SSIS Catalog Reports for package execution results."));
                    raiseEvent("Error", -1099, TaskName, msg);
                    ret = DTSExecResult.Failure;
                    break;
            }

            return ret;
        }

        private void stopExecution(long executionId
                         , SqlConnection connection)
        {
            CatalogCollection catalogCollection = new IntegrationServices(connection).Catalogs;
            Catalog catalog = catalogCollection[PackageCatalogName];
            ExecutionOperationCollection executionCollection = catalog.Executions;
            ExecutionOperation executionOperation = executionCollection[executionId];
            executionOperation.Stop();
        }

        private Operation.ServerOperationStatus returnOperationStatus(
                                            SqlConnection connection
                                          , long executionId)
        {
            CatalogCollection catalogCollection = new IntegrationServices(connection).Catalogs;
            Catalog catalog = catalogCollection[PackageCatalogName];
            OperationCollection operationCollection = catalog.Operations;
            Operation operation = operationCollection[executionId];
            Operation.ServerOperationStatus operationStatus = (Operation.ServerOperationStatus)operation.Status;

            return operationStatus;
        }


        private SqlConnection returnConnection()
        {
            return (SqlConnection)Connections[ConnectionManagerId].AcquireConnection(null);
        }

        private bool attemptConnection(Connections connections
                                     , int connectionManagerIndex)
        {
            bool ret = false;

            try
            {
                using (System.Data.SqlClient.SqlConnection con = returnConnection())
                {
                    if (con.State != System.Data.ConnectionState.Open)
                    {
                        con.Open();
                    }
                    ret = true;
                }
            }
            catch (Exception ex)
            {
                ret = false;
            }

            return ret;
        }

        public Catalog returnCatalog(string ServerName)
        {
            Catalog catalog = null;

            SqlConnection cn = (SqlConnection)Connections[ConnectionManagerId].AcquireConnection(null);
            integrationServices = new IntegrationServices(cn);
            if (integrationServices != null)
            {
                catalog = integrationServices.Catalogs[PackageCatalogName];
            }

            return catalog;
        }

        public CatalogFolder returnCatalogFolder(string ServerName
                                       , string FolderName)
        {
            CatalogFolder catalogFolder = null;

            SqlConnection cn = (SqlConnection)Connections[ConnectionManagerId].AcquireConnection(null);
            integrationServices = new IntegrationServices(cn);
            if (integrationServices != null)
            {
                catalog = integrationServices.Catalogs[PackageCatalogName];
                if (catalog != null)
                {
                    catalogFolder = catalog.Folders[FolderName];
                }
            }

            return catalogFolder;
        }

        public ProjectInfo returnCatalogProject(string ServerName
                                      , string FolderName
                                      , string ProjectName)
        {
            ProjectInfo catalogProject = null;

            SqlConnection cn = (SqlConnection)Connections[ConnectionManagerId].AcquireConnection(null);
            integrationServices = new IntegrationServices(cn);
            if (integrationServices != null)
            {
                catalog = integrationServices.Catalogs[PackageCatalogName];
                if (catalog != null)
                {
                    catalogFolder = catalog.Folders[FolderName];
                    if (catalogFolder != null)
                    {
                        catalogProject = catalogFolder.Projects[ProjectName];
                    }
                }
            }
            return catalogProject;
        }

        public Microsoft.SqlServer.Management.IntegrationServices.PackageInfo returnCatalogPackage(
                                                                                string ServerName
                                                                              , string FolderName
                                                                              , string ProjectName
                                                                              , string PackageName)
        {
            Microsoft.SqlServer.Management.IntegrationServices.PackageInfo catalogPackage = null;

            SqlConnection cn = (SqlConnection)Connections[ConnectionManagerId].AcquireConnection(null);
            integrationServices = new IntegrationServices(cn);
            if (integrationServices != null)
            {
                catalog = integrationServices.Catalogs[PackageCatalogName];
                if (catalog != null)
                {
                    catalogFolder = catalog.Folders[FolderName];
                    if (catalogFolder != null)
                    {
                        catalogProject = catalogFolder.Projects[ProjectName];
                        if (catalogProject != null)
                        {
                            catalogPackage = catalogProject.Packages[PackageName];
                        }
                    }
                }
            }

            return catalogPackage;
        }

        private Collection<Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet> returnExecutionValueParameterSet()
        {

            // initialize the parameters collection
            Collection<Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet> executionValueParameterSet = new Collection<Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet>();

            // set SYNCHRONIZED execution parameter
            executionValueParameterSet.Add(new Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet
            {
                ObjectType = 50,
                ParameterName = "SYNCHRONIZED",
                ParameterValue = false // always execute with the Synchronized property false
            });

            // set LOGGING_LEVEL execution parameter
            int LoggingLevelValue = decodeLoggingLevel(LoggingLevel);
            executionValueParameterSet.Add(new Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet
            {
                ObjectType = 50,
                ParameterName = "LOGGING_LEVEL",
                ParameterValue = LoggingLevelValue
            });

            // set CALLER_INFO execution parameter
            string machineName = Environment.MachineName.Replace('"', '\'').Replace("\\", "//");
            string userName = Environment.UserName;
            executionValueParameterSet.Add(new Microsoft.SqlServer.Management.IntegrationServices.PackageInfo.ExecutionValueParameterSet
            {
                ObjectType = 50,
                ParameterName = "CALLER_INFO",
                ParameterValue = machineName + "\\" + userName
            });
            return executionValueParameterSet;
        }


        private int decodeLoggingLevel(string loggingLevel)
        {
            int ret = 1;

            switch (loggingLevel)
            {
                default:
                    break;
                case "None":
                    ret = 0;
                    break;
                case "Performance":
                    ret = 2;
                    break;
                case "Verbose":
                    ret = 3;
                    break;
            }

            return ret;
        }

        private int returnConnectionManagerIndex(Connections connections
                                       , string connectionManagerName)
        {
            int ret = -1;

            try
            {
                ConnectionManagerId = GetConnectionID(connections, ConnectionManagerName);
                Microsoft.SqlServer.Dts.Runtime.ConnectionManager connectionManager = connections[ConnectionManagerId];
                ConnectionManagerName = connectionManager.Name;

                if (connectionManager != null)
                {
                    for (int i = 0; i <= connections.Count; i++)
                    {
                        if (connections[i].Name == connectionManager.Name)
                        {
                            ret = i;
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                string message = "Unable to locate connection manager: " + ConnectionManagerName;
                throw new Exception(message, ex.InnerException);
            }

            return ret;
        }

        public void raiseEvent(string messageType
                     , int messageCode
                     , string subComponent
                     , string message)
        {
            bool fireAgain = true;
            switch (messageType)
            {
                default:
                    break;
                case "Information":
                    componentEvents.FireInformation(messageCode, subComponent, message, "", 0, ref fireAgain);
                    break;
                case "Warning":
                    componentEvents.FireWarning(messageCode, subComponent, message, "", 0);
                    break;
                case "Error":
                    componentEvents.FireError(messageCode, subComponent, message, "", 0);
                    break;
            }
        }

    }

    class CheckWaitState
    {
        private long executionId;
        private int invokeCount;
        private ManualResetEvent manualResetState;
        private int maximumCount;
        private string catalogName;
        private SqlConnection connection;
        private ExecuteCatalogPackageTask task;
        public Operation.ServerOperationStatus OperationStatus { get; set; }

        public CheckWaitState(long executionId
                           , int maxCount
                           , SqlConnection connection
                           , string catalogName
                           , ExecuteCatalogPackageTask task)
        {
            this.executionId = executionId;
            this.invokeCount = 0;
            this.maximumCount = maxCount;
            this.connection = connection;
            this.catalogName = catalogName;
            this.task = task;
        }

        public void CheckStatus(object state)
        {
            TimerCheckerState localState = ((TimerCheckerState)state);
            this.manualResetState = localState.manualResetState;

            // increment the counter
            invokeCount++;

            // log this tick
            string msg = "Asynchronous Execution Retry Count: " + invokeCount.ToString() + " (Maximum Retry Count: " + maximumCount.ToString() + ")";

            this.task.raiseEvent("Information"
                               , 101
                               , this.task.TaskName + ".CheckStatus"
                               , msg);

            // check for package execution reached max count
            if (invokeCount == maximumCount)
            {
                // log maximumCount reached
                msg = "Asynchronous Execution Maximum Retry Count ("
                    + maximumCount.ToString() + ") reached.";
                this.task.raiseEvent("Information"
                                   , 101
                                   , this.task.TaskName + ".CheckStatus"
                                   , msg);

                // set OperationStatus
                OperationStatus = Operation.ServerOperationStatus.Canceled;

                // reset counter
                invokeCount = 0;

                // signal thread
                manualResetState.Set();
            }
            else
            {
                OperationStatus = returnOperationStatus();

                checkOperationStatus(OperationStatus);
            }
        }

        public Operation.ServerOperationStatus returnOperationStatus()
        {
            CatalogCollection catalogCollection = new IntegrationServices(connection).Catalogs;
            Catalog catalog = catalogCollection[catalogName];
            OperationCollection operationCollection = catalog.Operations;
            Operation operation = operationCollection[executionId];
            Operation.ServerOperationStatus operationStatus = operation.Status;

            return operationStatus;
        }

        public void checkOperationStatus(Operation.ServerOperationStatus operationStatus)
        {
            // check for package execution "finished" states
            if (
                (operationStatus == Operation.ServerOperationStatus.Canceled)
             || (operationStatus == Operation.ServerOperationStatus.Completion)
             || (operationStatus == Operation.ServerOperationStatus.Failed)
             || (operationStatus == Operation.ServerOperationStatus.Stopping)
             || (operationStatus == Operation.ServerOperationStatus.Success)
             || (operationStatus == Operation.ServerOperationStatus.UnexpectTerminated)
               )
            {
                // reset counter
                invokeCount = 0;
                // signal thread
                manualResetState.Set();
            }
        }
    }

    class TimerCheckerState
    {
        public ManualResetEvent manualResetState { get; private set; }

        public TimerCheckerState(ManualResetEvent manualResetState)
        {
            this.manualResetState = manualResetState;
        }
    }
}

