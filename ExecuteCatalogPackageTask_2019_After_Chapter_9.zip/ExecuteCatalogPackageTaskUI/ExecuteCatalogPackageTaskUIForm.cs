﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using Microsoft.SqlServer.Dts.Runtime;

namespace ExecuteCatalogPackageTaskUI
{
    public partial class ExecuteCatalogPackageTaskUIForm : Form
    {
        private TaskHost taskHost;

        public ExecuteCatalogPackageTaskUIForm(TaskHost taskHostValue)
        {
            InitializeComponent();
            taskHost = taskHostValue;
            txtInstance.Text = taskHost.Properties["ServerName"].GetValue(taskHost).ToString();
            txtFolder.Text = taskHost.Properties["PackageFolder"].GetValue(taskHost).ToString();
            txtProject.Text = taskHost.Properties["PackageProject"].GetValue(taskHost).ToString();
            txtPackage.Text = taskHost.Properties["PackageName"].GetValue(taskHost).ToString();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            taskHost.Properties["ServerName"].SetValue(taskHost, txtInstance.Text);
            taskHost.Properties["PackageFolder"].SetValue(taskHost, txtFolder.Text);
            taskHost.Properties["PackageProject"].SetValue(taskHost, txtProject.Text);
            taskHost.Properties["PackageName"].SetValue(taskHost, txtPackage.Text);
        }
    }
}
