﻿using Microsoft.SqlServer.Dts.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Management.IntegrationServices;
using Microsoft.SqlServer.Management.Smo;
using System.Data.SqlClient;

namespace ExecuteCatalogPackageTask
{
    [DtsTask(
      TaskType = "DTS150"
    , DisplayName = "Execute Catalog Package Task"
    , Description = "A task to execute packages stored in the SSIS Catalog."
    , UITypeName= "ExecuteCatalogPackageTaskUI.ExecuteCatalogPackageTaskUI, ExecuteCatalogPackageTaskUI, Version=1.0.0.0, Culture=Neutral, PublicKeyToken=44323611cf8b4a9c"
    , TaskContact = "ExecuteCatalogPackageTask; Building Custom Tasks for SQL Server Integration Services, 2019 Edition; © 2020 Andy Leonard; https://dilmsuite.com/ExecuteCatalogPackageTaskBookCode"
    , IconResource = "ExecuteCatalogPackageTask.ALCStrike.ico")]
    public class ExecuteCatalogPackageTask : Microsoft.SqlServer.Dts.Runtime.Task
    {
        // public key: 339881ec0c5b3453
        // UI public key: 44323611cf8b4a9c

        public string ServerName { get; set; } = String.Empty;
        public string PackageCatalog { get; } = "SSISDB";
        public string PackageFolder { get; set; } = String.Empty;
        public string PackageProject { get; set; } = String.Empty;
        public string PackageName { get; set; } = String.Empty;

        public override void InitializeTask(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSInfoEvents events,
            IDTSLogging log,
            EventInfos eventInfos,
            LogEntryInfos logEntryInfos,
            ObjectReferenceTracker refTracker)
        { }

        public override DTSExecResult Validate(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSComponentEvents componentEvents,
            IDTSLogging log)
        {
            return DTSExecResult.Success;
        }

        public override DTSExecResult Execute(
            Connections connections,
            VariableDispenser variableDispenser,
            IDTSComponentEvents componentEvents,
            IDTSLogging log,
            object transaction)
        {
            //Server catalogServer = new Server(ServerName);
            //IntegrationServices integrationServices = new IntegrationServices(catalogServer);
            string connectionString = String.Format(@"Data Source={0}; Initial Catalog=SSISDB; Integrated Security=True;"
                                                  , ServerName // 0
                                                  );
            SqlConnection sqlConnection = new SqlConnection(connectionString);
            IntegrationServices integrationServices = new IntegrationServices(sqlConnection);
            Catalog catalog = integrationServices.Catalogs[PackageCatalog];
            CatalogFolder catalogFolder = catalog.Folders[PackageFolder];
            ProjectInfo catalogProject = catalogFolder.Projects[PackageProject];
            Microsoft.SqlServer.Management.IntegrationServices.PackageInfo catalogPackage = catalogProject.Packages[PackageName];

            catalogPackage.Execute(false, null);

            return DTSExecResult.Success;
        }
    }
}
